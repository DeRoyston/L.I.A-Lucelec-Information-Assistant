# LUCELEC Contact Information

LUCELEC main office telephone number: 1 (758) 457-4400

Email: customersupport@lucelec.com

Customer service coverage by area:
- North St. Lucia (Cap Estate to Dennery and Canaries): 452-2165
- South St. Lucia: 454-6617 or 457-4800

If a customer needs to speak with a human about their account, bill, service issue, or appliance-related question, direct them to the LUCELEC contact details above.
