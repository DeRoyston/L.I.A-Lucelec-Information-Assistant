# Appliance Cost Estimator based on Model and Wattage

This document is for estimating the running cost of common household appliances using typical wattage values and example models.

## 1. Kitchen Appliances

### Refrigerator
- Typical wattage: 100W – 800W while running
- Example models:
  - Whirlpool WRT318FZDM (Top-Freezer): about 150W – 300W
  - LG LFXS26596S (French Door): about 400W – 700W

### Microwave Oven
- Typical wattage: 600W – 1,200W
- Example models:
  - Panasonic NN-SN686S: 1,200W
  - Toshiba EM925A5A-BS (Compact): 900W

### Dishwasher
- Typical wattage: 1,200W – 2,400W
- Example models:
  - Bosch 300 Series (SHEM63W55N): about 1,300W
  - KitchenAid KDTM404KPS: about 1,800W

### Electric Range / Oven
- Typical wattage: 2,000W – 5,000W
- Example models:
  - GE JB645RKSS (Electric Range): 2,500W for the oven, up to 5,000W when all burners are active

## 2. Climate Control & Heating

### Air Conditioner
- Typical wattage: 500W – 3,500W
- Example models:
  - Midea 8,000 BTU U-Smart (Window AC): about 710W
  - LG 12,000 BTU Dual Inverter (Portable AC): about 1,370W

### Space Heater
- Typical wattage: 750W – 1,500W
- Example models:
  - Lasko 754200 Ceramic Heater: 1,500W (High) / 900W (Low)
  - De'Longhi EW7707CM Oil-Filled Radiator: 1,500W

### Ceiling Fan
- Typical wattage: 15W – 75W
- Example models:
  - Big Ass Fans Haiku (DC Motor): about 15W – 30W
  - Hunter Builder Deluxe (AC Motor): about 60W – 75W

## 3. Laundry & Cleaning

### Washing Machine
- Typical wattage: 400W – 1,400W
- Example models:
  - Samsung WF45T6000AW (Front Load): about 500W – 1,000W
  - Maytag MVWC565FW (Top Load): about 500W – 800W

### Clothes Dryer
- Typical wattage: 1,800W – 5,000W
- Example models:
  - LG DLEX4000W (Electric Dryer): about 4,500W – 5,000W
  - Whirlpool WED4815EW (Standard Electric): about 4,500W

### Vacuum Cleaner
- Typical wattage: 500W – 1,400W
- Example models:
  - Dyson V15 Detect (Cordless): about 230W – 660W
  - Shark Navigator Lift-Away NV352: about 1,200W

## 4. Electronics & Entertainment

### Television
- Typical wattage: 30W – 300W
- Example models:
  - TCL 32-inch 3-Series LED TV: about 30W – 50W
  - LG C3 65-inch 4K OLED TV: about 130W – 220W

### Gaming Console
- Typical wattage: 70W – 220W
- Example models:
  - Nintendo Switch: about 10W – 18W
  - Sony PlayStation 5: about 160W – 210W under heavy load

## How to use this information
- Use the wattage and the number of hours used per day to estimate the daily and monthly cost.
- The final cost depends on the electricity rate, the appliance model, and how often the appliance is used.
