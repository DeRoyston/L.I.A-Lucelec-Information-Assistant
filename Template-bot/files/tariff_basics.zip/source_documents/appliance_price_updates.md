# Appliance Price Changes and Market Notes

Between June 1 and August 1, 2026, six major appliance manufacturers are raising prices by 3.5% to 12%.

The manufacturers named in this update are:
- ASKO
- GE
- KitchenAid
- LG
- Whirlpool
- Bosch / Thermador

This information can be used when a customer asks why a stove, refrigerator, or other appliance appears to cost more than it did in a previous month.
